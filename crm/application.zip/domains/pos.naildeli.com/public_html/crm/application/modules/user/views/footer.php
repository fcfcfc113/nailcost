<!-- BEGIN VENDOR JS-->

<script src="<?php echo assets_url(); ?>crm-assets/vendors/js/ui/perfect-scrollbar.jquery.min.js"
        type="text/javascript"></script>
<script src="<?php echo assets_url(); ?>crm-assets/vendors/js/ui/unison.min.js" type="text/javascript"></script>
<script src="<?php echo assets_url(); ?>crm-assets/vendors/js/ui/blockUI.min.js" type="text/javascript"></script>
<script src="<?php echo assets_url(); ?>crm-assets/vendors/js/ui/jquery.matchHeight-min.js" type="text/javascript"></script>
<script src="<?php echo assets_url(); ?>crm-assets/vendors/js/ui/screenfull.min.js" type="text/javascript"></script>
<script src="<?php echo assets_url(); ?>crm-assets/vendors/js/extensions/pace.min.js" type="text/javascript"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<!-- END PAGE VENDOR JS-->
<!-- BEGIN ROBUST JS-->
<script src="<?php echo assets_url(); ?>crm-assets/js/core/app-menu.js" type="text/javascript"></script>
<script src="<?php echo assets_url(); ?>crm-assets/js/core/app.js" type="text/javascript"></script>
<!-- END ROBUST JS-->
<!-- BEGIN PAGE LEVEL JS-->
<!-- END PAGE LEVEL JS-->
</body>
</html>