<!-- BEGIN VENDOR JS-->

<script src="<?php echo assets_url(); ?>crm-assets/myjs/jquery-ui.js"></script>
<script src="<?php echo assets_url(); ?>crm-assets/vendors/js/ui/perfect-scrollbar.jquery.min.js"
        type="text/javascript"></script>
<script src="<?php echo
assets_url(); ?>crm-assets/vendors/js/ui/unison.min.js" type="text/javascript"></script>
<script src="<?php echo assets_url(); ?>crm-assets/vendors/js/ui/blockUI.min.js" type="text/javascript"></script>
<script src="<?php echo assets_url(); ?>crm-assets/vendors/js/ui/jquery.matchHeight-min.js" type="text/javascript"></script>
<script src="<?php echo assets_url(); ?>crm-assets/vendors/js/ui/screenfull.min.js" type="text/javascript"></script>
<script src="<?php echo assets_url(); ?>crm-assets/vendors/js/extensions/pace.min.js" type="text/javascript"></script>
<script src="<?php echo assets_url(); ?>crm-assets/myjs/jquery.dataTables.min.js"></script>


<script type="text/javascript">var dtformat = $('#hdata').attr('data-df');
    var currency = $('#hdata').attr('data-curr');
    ;</script>
<script src="<?php echo assets_url(); ?>crm-assets/myjs/custom.js"></script>
<script src="<?php echo assets_url(); ?>crm-assets/myjs/basic.js"></script>
<script src="<?php echo assets_url(); ?>crm-assets/myjs/control.js"></script>

<script src="<?php echo assets_url(); ?>crm-assets/js/core/app.js" type="text/javascript"></script>
<script src="<?php echo assets_url(); ?>crm-assets/js/core/app-menu.js" type="text/javascript"></script>


</body>
</html>
